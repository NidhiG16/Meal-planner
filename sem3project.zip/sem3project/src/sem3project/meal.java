package sem3project;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */

import lunch.*;
import dinner.*;
import breakfast.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import static sem3project.table.dt;
public class meal extends Frame implements ActionListener {
    public static String age,days;
    public static int tcal_cntr;
    public static JComboBox c_day,c_age;
    public static JButton b1,b2,b3,table,tcal;
    public static JLabel l1 ;
    
    public static JPanel pane,day,pane1;
    public static JTextField dayfield;
    public static JFrame f1;
    public meal() throws IOException{
        
        tcal = new JButton("Total calories");
        tcal.addActionListener(this);
        table = new JButton("Meal plan");
        table.addActionListener(this);
        c_day = new JComboBox();
        c_age = new JComboBox();
        day = new JPanel();
        pane1 = new JPanel();
        dayfield = new JTextField(10);
        String[] days = {"Select a day","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
        String[] age = {"Select your age range","10-14","14-18","19-30","31-50","greater than 50"};
        c_age = new JComboBox(age);
        c_day = new JComboBox(days);
        c_day.setSelectedIndex(0);
        f1 = new JFrame();
        f1.setDefaultCloseOperation(EXIT_ON_CLOSE);
        b1=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\3rd Sem\\javaprjct\\brkfst.jpg")); 
        b2=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\3rd Sem\\javaprjct\\lun.jpg")); 
        b3=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\3rd Sem\\javaprjct\\din.jpg")); 
        l1=new JLabel();
        l1.setText("MEAL PLANNER");
        l1.setFont(new Font("Times New Roman",Font.ITALIC|Font.BOLD,40));
        pane = new JPanel(new BorderLayout(8,8));
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        l1.setHorizontalAlignment(JLabel.CENTER);
        l1.setVerticalAlignment(JLabel.CENTER);
        Border labelborder = new EmptyBorder(50,10,10,10);
        l1.setBorder(labelborder);
        f1.add(l1,BorderLayout.NORTH);
        pane.add(b1,BorderLayout.WEST);
        pane.add(b2,BorderLayout.CENTER);
        pane.add(b3,BorderLayout.EAST);
        pane.setLayout(new GridBagLayout());   
        pane1.add(c_day);
        pane1.add(c_age);
        pane1.add(table);
        pane1.add(tcal,BorderLayout.PAGE_END);
        f1.add(pane1,BorderLayout.PAGE_END);
        f1.add(pane);
        f1.pack();
        f1.setSize(900,600);
        f1.setLocationRelativeTo(null);
        f1.setVisible(true);
    }  
    @Override
    public void actionPerformed(ActionEvent a) {
        String ag = (String) c_age.getSelectedItem();
        String day = (String) c_day.getSelectedItem();
        
        try {
            tcal_cntr=breakfast.cntr+lunch.cntr+dinner.cntr;
           // dayfield.setText();
            //day.add(dayfield);
            if(a.getSource()==table){
                new table();
                new Planner(day);
                new Plann(day);
                new Plan_d(day);
            }
            if(a.getSource()==tcal){
                
                new Age(tcal_cntr,ag);
                
            }
            if(a.getSource()==b1){
                new breakfast();
            }
            if(a.getSource()==b2){
                new lunch();
            }
            if(a.getSource()==b3){
                new dinner();
            }
            
           // }
            f1.setVisible(false);
        } catch (IOException ex) {
            Logger.getLogger(meal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
            
    public static void main(String args[]) throws IOException {
        new meal();
    }
}





