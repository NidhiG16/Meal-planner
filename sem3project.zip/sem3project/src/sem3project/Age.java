/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sem3project;

import java.io.IOException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import static sem3project.meal.f1;

/**
 *
 * @author user
 */
public class Age extends JComboBox
{
    public static String snack;
        public Age(int c, String ch) throws IOException
                
	{       
            String snack=" ";
                if("10 -14".equals(ch))
		{
			if(c>2200){
                            JOptionPane.showMessageDialog(null, "Watch your calories");
                            new meal().repaint();
                            new meal();
                        }
                        else{
                            
                            JOptionPane.showInputDialog("Yay!!You're within your calorie limit.Add a snack as a reward!", snack);
                            new meal().repaint();
                            meal.f1.setVisible(true);
                        }
		}
                if("14-18".equals(ch))
		{
			if(c>2000){
                            JOptionPane.showMessageDialog(null, "Watch your calories");
                            new meal().repaint();
                            meal.f1.setVisible(true);;
                        }
                        else{
                            JOptionPane.showInputDialog("Yay!!You're within your calorie limit.Add a snack as a reward!", " ");
                            new meal().repaint();
                            meal.f1.setVisible(true);
                        }
		}

                if("19-30".equals(ch))
                {
                    if(c>2200){
                        JOptionPane.showMessageDialog(null, "Watch your calories");
                        new meal().repaint();
                        meal.f1.setVisible(true);
                        
                    }
                    else{
                         JOptionPane.showInputDialog("Yay!!You're within your calorie limit.Add a snack as a reward!", snack);
                         new meal().repaint();
                       meal.f1.setVisible(true);
                       
                    }
				
		}

                if("31-50".equals(ch))
		{
                    if(c>2000){
                        JOptionPane.showMessageDialog(null, "Watch your calories");
                        new meal().repaint();
                        meal.f1.setVisible(true);
                        
                    }
                    else{
                         JOptionPane.showInputDialog("Yay!!You're within your calorie limit.Add a snack as a reward!", snack);
                         new meal().repaint();
                        meal.f1.setVisible(true);
                    }
		}

                if("greater than 50".equals(ch))
		{
                    if(c>1800){
                        JOptionPane.showMessageDialog(null, "Watch your calories");
                        new meal().repaint();
                        meal.f1.setVisible(true);
                        
                    }
                    else{
                        JOptionPane.showInputDialog("Yay!!You're within your calorie limit.Add a snack as a reward!", snack);
                        new meal().repaint();
                        meal.f1.setVisible(true);
                        
                    }
		}
                if("Select your age range".equals(ch)){
                    if(meal.tcal.hasFocus()){
                        JOptionPane.showMessageDialog(f1, "Please select your age range to continue");
                        new meal().repaint();
                        meal.f1.setVisible(true);
                    }
                }
                if(JOptionPane.OK_OPTION==1){
                    new meal().repaint();
                    meal.f1.setVisible(true);
                }
                
	}

 
}