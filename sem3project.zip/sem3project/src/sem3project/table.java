/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sem3project;


import breakfast.Planner;
import dinner.Plan_d;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.*;
import javax.swing.*;
import lunch.Plann;
/**
 *
 * @author user
 */
public class table implements ActionListener{
    public static JFrame plan;
    public JButton bck,update;
    public static JTextArea i;
    public JPanel btn;
    public static JTable table;
    public static DefaultTableModel dt;
    public table() throws IOException{
        
        btn = new JPanel();
        plan = new JFrame();
        String days[][] = {{"Sunday"," "," "," "," "},{"Monday"," "," "," "," "},{"Tuesday"," "," "," "," "},{"Wednesday"," "," "," "," "},{"Thursday"," "," "," "," "},{"Friday"," "," "," "," "},{"Saturday"," "," "," "," "}};
        String meal[] = {"Days","Breakfast","Lunch","Dinner","Snack"};
        dt = new  DefaultTableModel(days, meal);
        table = new JTable(dt);
        table.setModel(dt);
        
        table.setRowHeight(table.getRowHeight() + 50);
        bck = new JButton("BACK");
        bck.addActionListener(this);
        //dt.fireTableDataChanged();
        //plan.add(i);
        btn.add(bck,BorderLayout.SOUTH);
        plan.add(btn,BorderLayout.SOUTH);
        plan.setSize(900,600); 
        plan.add(table.getTableHeader(), BorderLayout.PAGE_START);
        plan.add(table, BorderLayout.CENTER);
        plan.setLocationRelativeTo(null);
        plan.setVisible(true);
        
    }
    
   class Snack extends table{
        //public static DefaultTableModel d;
        public Snack(String d) throws IOException{
            switch(d){
                case "Sunday"->{
                    dt.setValueAt(Age.snack, 0, 4);
                    dt.fireTableCellUpdated(0,4);

                }
                case "Monday"->{
                    dt.setValueAt(Age.snack, 1, 4);
                    dt.fireTableCellUpdated(1,4);
                }
                case "Tuesday"->{
                    dt.setValueAt(Age.snack, 2, 4);
                    dt.fireTableCellUpdated(2,4);
                }
                case "Wednesday"->{
                    dt.setValueAt(Age.snack, 3, 4);
                    dt.fireTableCellUpdated(3,4);
                }
                case "Thursday"->{
                    dt.setValueAt(Age.snack, 4, 4);
                    dt.fireTableCellUpdated(4,4);
                }
                case "Friday"->{
                    dt.setValueAt(Age.snack, 5, 4);
                    dt.fireTableCellUpdated(5,4);
                }
                case "Saturday"->{
                    dt.setValueAt(Age.snack, 6, 4);
                    dt.fireTableCellUpdated(6,4);
                }   
                
            }
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==bck){
            try {
                dt.fireTableDataChanged();
                new meal();
                plan.setVisible(false);
                
            } catch (IOException ex) {
                Logger.getLogger(table.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
   
}
