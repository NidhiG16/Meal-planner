/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dinner;
/**
 *
 * @author user
 */
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sem3project.*;

/**
 *
 * @author user
 */
public class Plan_d extends JComboBox {
     public DefaultTableModel t;
   public Plan_d(String d) throws IOException{
       t = table.dt;
       switch (d) {
           case "Sunday" -> {
               if(dinner.mc.isEnabled()){
                   t.setValueAt("Mac and cheese", 0, 3); 
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.fa.isEnabled()){
                   t.setValueAt("Fajitas", 0, 3);
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.dp.isEnabled()){
                   t.setValueAt("Deep Dish Pizza", 0, 3);
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.bbq.isEnabled()){
                   t.setValueAt("Barbecue Ribs", 0, 3);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(dinner.philly.isEnabled()){
                   t.setValueAt("Philly Cheessteak", 0, 3);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(dinner.reuben.isEnabled()){
                   t.setValueAt("Reuben sandwich", 0, 3);
                   //t.fireTableCellUpdated(0,2);
               }else{
                   System.out.println("g");
                   break;
               }
                //t.fireTableCellUpdated(0,3);
           }
           case "Monday" -> {
               if(dinner.mc.isEnabled()){
                   t.setValueAt("Mac and cheese", 1, 3); 
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.fa.isEnabled()){
                   t.setValueAt("Fajitas", 1, 3);
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.dp.isEnabled()){
                   t.setValueAt("Deep Dish Pizza", 1, 3);
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.bbq.isEnabled()){
                   t.setValueAt("Barbecue Ribs", 1, 3);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(dinner.philly.isEnabled()){
                   t.setValueAt("Philly Cheessteak", 1, 3);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(dinner.reuben.isEnabled()){
                   t.setValueAt("Reuben sandwich", 1, 3);
                   //t.fireTableCellUpdated(0,2);
               }else{
                   break;
               }
                //t.fireTableCellUpdated(1,3);
           }
           case "Tuesday" -> {
                if(dinner.mc.isEnabled()){
                   t.setValueAt("Mac and cheese", 2, 3); 
                  // t.fireTableCellUpdated(0,3);
               }
                else if(dinner.fa.isEnabled()){
                   t.setValueAt("Fajitas", 2, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.dp.isEnabled()){
                   t.setValueAt("Deep Dish Pizza", 2, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.bbq.isEnabled()){
                   t.setValueAt("Barbecue Ribs", 2, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.philly.isEnabled()){
                   t.setValueAt("Philly Cheessteak", 2, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.reuben.isEnabled()){
                   t.setValueAt("Reuben sandwich", 2, 3);
                   //t.fireTableCellUpdated(0,2);
               }else{
                    break;
                }
                t.fireTableCellUpdated(2,3);
           }
           case "Wednesday" -> {
                if(dinner.mc.isEnabled()){
                   t.setValueAt("Mac and cheese", 3, 3); 
                  // t.fireTableCellUpdated(0,3);
               }
                else if(dinner.fa.isEnabled()){
                   t.setValueAt("Fajitas", 3, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.dp.isEnabled()){
                   t.setValueAt("Deep Dish Pizza", 3, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.bbq.isEnabled()){
                   t.setValueAt("Barbecue Ribs", 3, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.philly.isEnabled()){
                   t.setValueAt("Philly Cheessteak", 3, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.reuben.isEnabled()){
                   t.setValueAt("Reuben sandwich", 3, 3);
                   //t.fireTableCellUpdated(0,2);
               }else{
                    break;
                }
                t.fireTableCellUpdated(3,3);
           }
           case "Thursday" -> {
                if(dinner.mc.isEnabled()){
                   t.setValueAt("Mac and cheese", 4, 3); 
                  // t.fireTableCellUpdated(0,3);
               }
                else if(dinner.fa.isEnabled()){
                   t.setValueAt("Fajitas",4, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.dp.isEnabled()){
                   t.setValueAt("Deep Dish Pizza", 4, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.bbq.isEnabled()){
                   t.setValueAt("Barbecue Ribs", 4, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.philly.isEnabled()){
                   t.setValueAt("Philly Cheessteak", 4, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.reuben.isEnabled()){
                   t.setValueAt("Reuben sandwich", 4, 3);
                   //t.fireTableCellUpdated(0,2);
               }else{
                    break;
                }
                t.fireTableCellUpdated(4,3);
           }
           case "Friday" -> {
               if(dinner.mc.isEnabled()){
                   t.setValueAt("Mac and cheese", 5, 3); 
                  // t.fireTableCellUpdated(0,3);
               }
               else if(dinner.fa.isEnabled()){
                   t.setValueAt("Fajitas", 5, 3);
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.dp.isEnabled()){
                   t.setValueAt("Deep Dish Pizza", 5, 3);
                   //t.fireTableCellUpdated(0,3);
               }
               else if(dinner.bbq.isEnabled()){
                   t.setValueAt("Barbecue Ribs", 5, 3);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(dinner.philly.isEnabled()){
                   t.setValueAt("Philly Cheessteak", 5, 3);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(dinner.reuben.isEnabled()){
                   t.setValueAt("Reuben sandwich", 5, 3);
                   //t.fireTableCellUpdated(0,2);
               }else{
                   break;
               }
                t.fireTableCellUpdated(5,3);
           }
           case "Saturday" -> {
                if(dinner.mc.isEnabled()){
                   t.setValueAt("Mac and cheese", 6, 3); 
                  // t.fireTableCellUpdated(0,3);
               }
                else if(dinner.fa.isEnabled()){
                   t.setValueAt("Fajitas", 6, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.dp.isEnabled()){
                   t.setValueAt("Deep Dish Pizza", 6, 3);
                   //t.fireTableCellUpdated(0,3);
               }
                else if(dinner.bbq.isEnabled()){
                   t.setValueAt("Barbecue Ribs", 6, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.philly.isEnabled()){
                   t.setValueAt("Philly Cheessteak", 6, 3);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(dinner.reuben.isEnabled()){
                   t.setValueAt("Reuben sandwich", 6, 3);
                   //t.fireTableCellUpdated(0,2);
               }else{
                    break;
                }
                t.fireTableCellUpdated(6,3);
           }
           
       
       }

      t.fireTableRowsUpdated(0, 6);
       
       }
    }



