/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dinner;

/**
 *
 * @author user
 */
import java.io.*;
import java.util.*;
import javax.swing.*;
public class Calories {
    public static String line;
    public static ArrayList ing_m,ing;
    public static String[] im;
    public static int calo_m;
    public static BufferedReader bm;
    public static File rm;
    public static JTextArea ta_m,ta_cal_m;
    public Calories() throws IOException{   
        ArrayList<String> ing_m = new ArrayList<String>();
        ArrayList<String> ing = new ArrayList<String>();
        ta_m = new JTextArea();
        ta_cal_m = new JTextArea();
        try{
            rm = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\ing\\Mac_and_cheese.txt");
            bm = new BufferedReader(new FileReader(rm));  
            while ((line=bm.readLine())!=null) {
                    im = line.split("-");
                    Collections.addAll(ing, im[1]);
                    Collections.addAll(ing_m, im[0]);
             }
            calo_m=0;
            for (String C: ing) {
                    calo_m += Integer.parseInt(C);
                    ta_cal_m.append("\n"+C);
                }            
            for(String I:ing_m){
                    ta_m.append("\n"+I);
                }
            
            ta_m.setEditable(false);
            bm.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
class Fajitas{
             public static String faj;
             public static ArrayList ing_f,ing;
             public static String[] i_f;
             public static int calo_f;
             public static BufferedReader bf;
             public static File rf;
             public static JTextArea ta_f,ta_cal_f;
             public Fajitas()throws IOException{
                ArrayList<String> ing_f = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_f = new JTextArea();
                ta_cal_f = new JTextArea();
                try{
                    rf = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\ing\\Fajitas.txt");
                    bf = new BufferedReader(new FileReader(rf));  
                    while ((faj=bf.readLine())!=null) {
                        i_f = faj.split("-");
                       Collections.addAll(ing, i_f[1]);
                        Collections.addAll(ing_f, i_f[0]);
                }
                calo_f=0;
                for (String C: ing) {
                        calo_f += Integer.parseInt(C);
                        ta_cal_f.append("\n"+C);
                }            
                for(String I:ing_f){
                    ta_f.append("\n"+I);
                }
            
                ta_f.setEditable(false);
                bf.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Reuben{
             public static String reu;
             public static ArrayList ing_r,ing;
             public static String[] i;
             public static int calo_r;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_r,ta_cal_r;
             public Reuben()throws IOException{
                ArrayList<String> ing_r = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_r = new JTextArea();
                ta_cal_r = new JTextArea();
                try{
                    r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\ing\\Reuben_Sandwich.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((reu=b.readLine())!=null) {
                        i = reu.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_r, i[0]);
                }
                calo_r=0;
                for (String C: ing) {
                        calo_r += Integer.parseInt(C);
                        ta_cal_r.append("\n"+C);
                }            
                for(String I:ing_r){
                    ta_r.append("\n"+I);
                }
            
                ta_r.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Barbecue{
             public static String barb;
             public static ArrayList ing_b,ing;
             public static String[] i;
             public static int calo_b;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_b,ta_cal_b;
             public Barbecue()throws IOException{
                ArrayList<String> ing_f = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_b = new JTextArea();
                ta_cal_b = new JTextArea();
                try{
                    r= new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\ing\\Barbecue_ribs.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((barb=b.readLine())!=null) {
                        i = barb.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_f, i[0]);
                }
                calo_b=0;
                for (String C: ing) {
                        calo_b += Integer.parseInt(C);
                        ta_cal_b.append("\n"+C);
                }            
                for(String I:ing_f){
                    ta_b.append("\n"+I);
                }
            
                ta_b.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Philly{
             public static String phi;
             public static ArrayList ing_p,ing;
             public static String[] i;
             public static int calo_p;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_p,ta_cal_p;
             public Philly()throws IOException{
                ArrayList<String> ing_f = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_p = new JTextArea();
                ta_cal_p = new JTextArea();
                try{
                    r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\ing\\Philly_Cheesesteak.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((phi=b.readLine())!=null) {
                        i = phi.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_f, i[0]);
                }
                calo_p=0;
                for (String C: ing) {
                        calo_p += Integer.parseInt(C);
                        ta_cal_p.append("\n"+C);
                }            
                for(String I:ing_f){
                    ta_p.append("\n"+I);
                }
            
                ta_p.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Pizza{
     public static String line;
    public static ArrayList ing_pi,ing;
    public static String[] i_pi;
    public static int calo_pi;
    public static BufferedReader b_pi;
    public static File r_pi;
    public static JTextArea ta_pi,ta_cal_pi;
    public Pizza() throws IOException{
            ArrayList<String> ing_pi = new ArrayList<String>();
            ArrayList<String> ing = new ArrayList<String>();
            ta_pi = new JTextArea();
            ta_cal_pi = new JTextArea();
            try{
                r_pi = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\ing\\Deep_dish_pizza.txt");
                b_pi = new BufferedReader(new FileReader(r_pi));  
                while ((line=b_pi.readLine())!=null) {
                        i_pi = line.split("-");
                        Collections.addAll(ing, i_pi[1]);
                        Collections.addAll(ing_pi, i_pi[0]);
                }
                calo_pi=0;
                for (String C: ing) {
                        calo_pi += Integer.parseInt(C);
                        ta_cal_pi.append("\n"+C);
                }            
                for(String I:ing_pi){
                    ta_pi.append("\n"+I);
                }
            
                ta_pi.setEditable(false);
                b_pi.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
           
   
}
     


