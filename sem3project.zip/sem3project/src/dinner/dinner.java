/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dinner;

/**
 *
 * @author user
 */

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.io.IOException;
import sem3project.*;
import static sem3project.table.dt;
public class dinner extends JFrame implements ActionListener{
    public static String d_m,d_f,d_p,d_b,d_ph,d_r; 
    public static int cntr=0;
    public JLabel l4,count,l5;
    public JList mc_ing,fa_ing,dp_ing;
    public JPanel ing,ing_d,btn,btn_cal;
    public static JButton mc,fa,dp,bck,cal_cntr,bbq,reuben,philly,update;
    public JFrame f4;
    public static JTextPane ta;
    public static JScrollPane scroll;
    public static JComboBox combobx;
    public Box b,bb;
    public dinner() throws IOException
    {
        ta=new JTextPane();
        ta.setPreferredSize(new Dimension(400,430));
        ta.setEditable(false);
        scroll=new JScrollPane(ta);
        scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        scroll.setHorizontalScrollBarPolicy ( ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS );
        ing = new JPanel(new BorderLayout());
        count=new JLabel();
        btn = new JPanel();
        btn_cal = new JPanel();
        bck = new JButton("BACK");
        f4 = new JFrame();
        cal_cntr = new JButton("Calorie Counter");
        cal_cntr.addActionListener(this);
        bck.addActionListener(this);
        btn_cal.add(count);
        btn_cal.add(cal_cntr,BorderLayout.PAGE_END);
        update=new JButton("UPDATE");
        btn.add(bck,BorderLayout.LINE_END);
        //ing.add(btn,BorderLayout.LINE_END);
        ing_d = new JPanel();
        new Calories();
        new Fajitas();
        new Reuben();
        new Barbecue();
        new Philly();
        new Pizza();
        l4=new JLabel();
        l4.setText("Choose your dinner");
        l4.setFont(new Font("Times New Roman",Font.ITALIC|Font.BOLD,20));
        l4.setHorizontalAlignment(JLabel.LEFT);
        f4.add(l4,BorderLayout.NORTH);
        ing = new JPanel(new BorderLayout(8,8));
        mc=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\imgs\\mc.jpg")); 
        mc.setText("Mac and Cheese");
        fa=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\imgs\\faj.jpg")); 
        fa.setText("Fajitas");
        dp=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\imgs\\piz.jpg"));
        dp.setText("Deep Dish Pizza");
        bbq=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\imgs\\bbq.jpg")); 
        bbq.setText("Barbecue Ribs");
        reuben=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\imgs\\reuben.jpg")); 
        reuben.setText("Reuben Sandwich");
        philly=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\dinner\\imgs\\philly.jpg"));
        philly.setText("Philly Cheesesteak");
        mc.addActionListener(this);
        fa.addActionListener(this);
        dp.addActionListener(this);
        bbq.addActionListener(this);
        reuben.addActionListener(this);
        philly.addActionListener(this);
        b=Box.createVerticalBox();
       bb = Box.createHorizontalBox();
        b.add(mc);
        b.add(fa);
        b.add(dp);
        b.add(bbq);
        b.add(reuben);
        b.add(philly);
        b.setEnabled(false);
        ing.add(b);
        bb.add(btn);
        bb.add(btn_cal);
        bb.add(update);
        Border btn_border = new EmptyBorder(20,20,20,20);
        ing.setBorder(btn_border);
        ing_d.add(scroll);
        f4.add(ing_d,BorderLayout.WEST);
        f4.add(ing,BorderLayout.WEST);
        f4.add(bb,BorderLayout.SOUTH);
        pack();
        f4.setSize(900, 600);
        f4.setLocationRelativeTo(null);
        f4.setVisible(true);
    }
    public void actionPerformed(ActionEvent a) {
        l5 = new JLabel("Ingredients",JLabel.CENTER);
        l5.setFont(new Font("Times New Roman",Font.ITALIC|Font.BOLD,20));
        f4.add(l5,BorderLayout.NORTH);
        //cntr=0;
        if(a.getSource()==mc){  
            ta.setText("");
            ta.insertComponent(Calories.ta_m);
            cntr+=Calories.calo_m;
            b.setEnabled(false);
            mc.setEnabled(true);
        }
        if(a.getSource()==fa){
            ta.setText("");
            ta.insertComponent(Fajitas.ta_f);
            cntr+=Fajitas.calo_f;
            b.setEnabled(false);
            fa.setEnabled(true);
        }
        if(a.getSource()==dp){
            ta.setText("");
            ta.insertComponent(Pizza.ta_pi);
            cntr+=Pizza.calo_pi;
            b.setEnabled(false);
            dp.setEnabled(true);  
        }
        if(a.getSource()==bbq){
            ta.setText("");
            ta.insertComponent(Barbecue.ta_b);
            cntr+=Barbecue.calo_b;
            b.setEnabled(false);
            bbq.setEnabled(true);   
        }
        if(a.getSource()==reuben){
            ta.setText("");
            ta.insertComponent(Reuben.ta_r);
            cntr+=Reuben.calo_r;
            b.setEnabled(false);
            reuben.setEnabled(true);  
        }
        if(a.getSource()==philly){
            ta.setText("");
            ta.insertComponent(Philly.ta_p);
            cntr+=Philly.calo_p;
            b.setEnabled(false);
            philly.setEnabled(true);   
        }
        if(a.getSource()==cal_cntr){
            count.setText("Calorie content: "+cntr+"cal");
            count.setFont(new Font("Times New Roman",Font.BOLD,20));            
        } 
        if(a.getSource()==update){
            
                dt.fireTableDataChanged();
           
        }
        ing.add(ing_d,BorderLayout.CENTER);
        f4.add(ing,BorderLayout.CENTER);
        f4.setVisible(true);
        if(a.getSource()==bck)
        {
            meal.f1.setVisible(true);
            f4.setVisible(false);
        }
        else{
            f4.setVisible(true);
        
            }
        
        
    }
}


