 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package breakfast;

/**
 *
 * @author user
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import static breakfast.breakfast.tab;
import dinner.Plan_d;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import lunch.Plann;
import sem3project.*;
import static sem3project.table.dt;
import static sem3project.table.table;

    public class breakfast extends Frame implements ActionListener{
    public static String b_p,b_w,b_a,cal,brkfst,b_bis,b_bur,b_fren; 
    public static int cntr=0;
    public static JList list;
    public static JLabel l2,count,l6;
    public static JButton pan,chkn,av,bck,cal_cntr,bur,fren,bisc,update;
    public static JPanel ing,ing_d,btn,btn_cal;
    public static JScrollPane scroll;
    public static JScrollBar scrollbar;
    public static JComboBox combobox;
    public static JFrame f2;
    public static String[] tab;
    public static JTextPane ta;
    public static Box b,bb;
    public breakfast () throws IOException   
    { 
        String tab[] = {b_p,b_w};
        ta=new JTextPane();
        ta.setPreferredSize(new Dimension(400,430));
        ta.setEditable(false);
        scroll=new JScrollPane(ta);
        scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        ing = new JPanel(new BorderLayout());
        count=new JLabel();
        btn = new JPanel();
        btn_cal = new JPanel();
        bck = new JButton("BACK");
        f2 = new JFrame();
        cal_cntr = new JButton("Calorie Counter");
        cal_cntr.addActionListener(this);
        bck.addActionListener(this);
        btn_cal.add(count);
        combobox=new JComboBox();
        update=new JButton("UPDATE");
        btn_cal.add(cal_cntr,BorderLayout.PAGE_END);
        btn.add(bck,BorderLayout.LINE_END);
        ing_d = new JPanel();
        new Calories();
        new Pancakes();
        new Avocado();
        new Biscuits();
        new Burrito();
        new French();
        l2=new JLabel();
        l6 = new JLabel();
        l2.setText("Choose your breakfast");
        l2.setFont(new Font("Times New Roman",Font.ITALIC|Font.BOLD,20));
        l2.setHorizontalAlignment(JLabel.LEFT);
        ing = new JPanel(new BorderLayout());
        f2.add(l2,BorderLayout.NORTH);
        av=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\imgs\\avo.jpg")); 
        av.setText("Avocado Toast");
        bisc=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\imgs\\bisc.jpg")); 
        bisc.setText("Biscuits and Gravy");
        bur=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\imgs\\burr.jpg"));
        bur.setText("Breakfast Burrito");
        chkn=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\imgs\\chicken_waffles.jpg")); 
        chkn.setText("Chicken Waffles");
        fren=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\imgs\\fren.jpg")); 
        fren.setText("French Toast Casserole");
        pan=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\imgs\\pancake.jpg"));
        pan.setText("Pancakes");
        pan.addActionListener(this);
        chkn.addActionListener(this);
        av.addActionListener(this);
        bisc.addActionListener(this);
        fren.addActionListener(this);
        bur.addActionListener(this);
        b = Box.createVerticalBox();
        bb = Box.createHorizontalBox();
        b.add(pan);
        b.add(chkn);
        b.add(av);
        b.add(bisc);
        b.add(bur);
        b.add(fren);
        ing.add(b);
        b.setEnabled(false);
        bb.add(btn);
        bb.add(btn_cal);
        bb.add(update);
        Border btn_border = new EmptyBorder(20,20,20,20);
        ing.setBorder(btn_border);
        ing_d.add(scroll);
        f2.add(ing_d,BorderLayout.WEST);
        f2.add(ing,BorderLayout.WEST);
        f2.add(bb,BorderLayout.SOUTH);
        pack();
        f2.setSize(900, 600);
        f2.setLocationRelativeTo(null);
        f2.setVisible(true);
    }
    public void actionPerformed(ActionEvent a) {
        l6 = new JLabel("Ingredients",JLabel.CENTER);
        l6.setFont(new Font("Times New Roman",Font.ITALIC|Font.BOLD,20));
        f2.add(l6,BorderLayout.NORTH);
     
        if(a.getSource()==pan){  
            ta.setText("");
            ta.insertComponent(Pancakes.ta_p);
            cntr+=Pancakes.calo_p;
            b.setEnabled(false);
            pan.setEnabled(true);
        }
        if(a.getSource()==chkn){
            ta.setText("");
            ta.insertComponent(Calories.ta);
            cntr+=Calories.calo;
            b.setEnabled(false);
            chkn.setEnabled(true);
        }
        if(a.getSource()==av){
            ta.setText("");
            ta.insertComponent(Avocado.ta_a);
            cntr+=Avocado.calo_a;
            b.setEnabled(false);
            av.setEnabled(true); 
        }
        if(a.getSource()==bisc){
            ta.setText("");
            ta.insertComponent(Biscuits.ta_b);
            cntr+=Biscuits.calo_b;
            b.setEnabled(false);
            bisc.setEnabled(true);   
        }
        if(a.getSource()==bur){
            ta.setText("");
            ta.insertComponent(Burrito.ta_bur);
            cntr+=Burrito.calo_bur;
            b.setEnabled(false);
            bur.setEnabled(true);
        }
        if(a.getSource()==fren){
            ta.setText("");
            ta.insertComponent(French.ta_f);
            cntr+=French.calo_f;
            b.setEnabled(false);
            bur.setEnabled(true); 
        }
        if(a.getSource()==cal_cntr){
            count.setText("Calorie content: "+cntr+"cal");
            count.setFont(new Font("Times New Roman",Font.BOLD,20));            
        }
        if(a.getSource()==update){
            dt.fireTableDataChanged();
           
           
        }
        ing.add(ing_d,BorderLayout.CENTER);
        f2.add(ing,BorderLayout.CENTER);
        f2.setVisible(true);
        if(a.getSource()==bck)
        {
            meal.f1.setVisible(true);
            f2.setVisible(false);
        }
        else{
            f2.setVisible(true);
        
            }
        
        
    }
}


