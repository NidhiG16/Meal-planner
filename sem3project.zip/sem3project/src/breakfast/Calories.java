/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package breakfast;

/**
 *
 * @author user
 */

import java.io.*;
import java.util.*;
import javax.swing.*;
public class Calories {
    public static String line;
    public static ArrayList ing_w,ing,cal_w;
    public static String[] i;
    public static int calo;
    public static BufferedReader b;
    public static File r;
    public static JTextArea ta,ta_cal;
    public Calories() throws IOException{   
        ArrayList<String> ing_w = new ArrayList<String>();
        ArrayList<String> ing = new ArrayList<String>();
        ta = new JTextArea();
        ta_cal = new JTextArea();
        try{
            
            r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\ing\\Waffles.txt");
            
            b = new BufferedReader(new FileReader(r)); 
            while ((line=b.readLine())!=null) {
                    i = line.split("-");
                    Collections.addAll(ing, i[1]);
                    Collections.addAll(ing_w, i[0]);
                    
             }
            calo=0;
            for (String C: ing) {
                    calo += Integer.parseInt(C);
            }            
            for(String I:ing_w){
                    ta.append("\n"+I);
                    
                }
            
            ta.setEditable(false);
            b.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
class Pancakes{
             public static String panc;
             public static ArrayList ing_p,ing,cal_p;
             public static String[] ip;
             public static int calo_p;
             public static BufferedReader bp;
             public static File rp;
             public static JTextArea ta_p,ta_cal_p;
             public Pancakes()throws IOException{
                ArrayList<String> ing_p = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_p = new JTextArea();
                ta_cal_p = new JTextArea();
                try{
                    rp = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\ing\\Pancakes.txt");
                    bp = new BufferedReader(new FileReader(rp));  
                    while ((panc=bp.readLine())!=null) {
                        ip = panc.split("-");
                       Collections.addAll(ing, ip[1]);
                        Collections.addAll(ing_p, ip[0]);
                }
                calo_p=0;
                for (String C: ing) {
                        calo_p += Integer.parseInt(C);
                        ta_cal_p.append("\n"+C);
                }            
                for(String I:ing_p){
                    ta_p.append("\n"+I);
                }
            
                ta_p.setEditable(false);
                bp.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Biscuits{
             public static String bisc;
             public static ArrayList ing_b,ing,cal_b;
             public static String[] ib;
             public static int calo_b;
             public static BufferedReader b;
             public static File rb;
             public static JTextArea ta_b,ta_cal_b;
             public Biscuits()throws IOException{
                ArrayList<String> ing_b = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                //ArrayList cal_p = new ArrayList();
                ta_b = new JTextArea();
                ta_cal_b = new JTextArea();
                try{
                    rb = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\ing\\Biscuit_gravy.txt");
                    b= new BufferedReader(new FileReader(rb));  
                    while ((bisc=b.readLine())!=null) {
                        ib = bisc.split("-");
                       Collections.addAll(ing, ib[1]);
                        Collections.addAll(ing_b, ib[0]);
                }
                calo_b=0;
                for (String C: ing) {
                        calo_b += Integer.parseInt(C);
                        ta_cal_b.append("\n"+C);
                }            
                for(String I:ing_b){
                    ta_b.append("\n"+I);
                }
            
                ta_b.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Burrito{
             public static String burr;
             public static ArrayList ing_bur,ing,cal_bur;
             public static String[] i;
             public static int calo_bur;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_bur,ta_cal_bur;
             public Burrito()throws IOException{
                ArrayList<String> ing_bur = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_bur = new JTextArea();
                ta_cal_bur = new JTextArea();
                try{
                    r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\ing\\burrito.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((burr=b.readLine())!=null) {
                        i = burr.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_bur, i[0]);
                }
                calo_bur=0;
                for (String C: ing) {
                        calo_bur += Integer.parseInt(C);
                        ta_cal_bur.append("\n"+C);
                }            
                for(String I:ing_bur){
                    ta_bur.append("\n"+I);
                }
            
                ta_bur.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class French{
             public static String fren;
             public static ArrayList ing_f,ing,cal_f;
             public static String[] i;
             public static int calo_f;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_f,ta_cal_f;
             public French()throws IOException{
                ArrayList<String> ing_f = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_f = new JTextArea();
                ta_cal_f = new JTextArea();
                try{
                    r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\ing\\french_toast.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((fren=b.readLine())!=null) {
                        i = fren.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_f, i[0]);
                }
                calo_f=0;
                for (String C: ing) {
                        calo_f += Integer.parseInt(C);
                        ta_cal_f.append("\n"+C);
                }            
                for(String I:ing_f){
                    ta_f.append("\n"+I);
                }
            
                ta_f.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Avocado{
     public static String line;
    public static ArrayList ing_a,ing,cal_a;
    public static String[] ia;
    public static int calo_a;
    public static BufferedReader ba;
    public static File ra;
    public static JTextArea ta_a,ta_cal_a;
    public Avocado() throws IOException{
            ArrayList<String> ing_a = new ArrayList<String>();
            ArrayList<String> ing = new ArrayList<String>();
            ta_a = new JTextArea();
            ta_cal_a = new JTextArea();
            try{
                ra = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\breakfast\\ing\\Avacado_toast.txt");
                ba = new BufferedReader(new FileReader(ra));  
                while ((line=ba.readLine())!=null) {
                        ia = line.split("-");
                        Collections.addAll(ing, ia[1]);
                        Collections.addAll(ing_a, ia[0]);
                }
                calo_a=0;
                for (String C: ing) {
                        calo_a += Integer.parseInt(C);
                        ta_cal_a.append("\n"+C);
                }            
                for(String I:ing_a){
                    ta_a.append("\n"+I);
                }
            
                ta_a.setEditable(false);
                ba.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
           
   
}
     

