/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package breakfast;

import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sem3project.*;

/**
 *
 * @author user
 */
public class Planner  {
     public DefaultTableModel t;
   public Planner(String d) throws IOException{
       t = table.dt;
       switch (d) {
           case "Sunday" -> {
               if(breakfast.pan.isEnabled()){
                   t.setValueAt("Pancakes", 0, 1);  
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.chkn.isEnabled()){
                   t.setValueAt("Chicken waffles", 0, 1);
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.av.isEnabled()){
                   t.setValueAt("Avocado toast", 0, 1);
                  //t.fireTableCellUpdated(0,1);
               }
               else if(breakfast.bisc.isEnabled()){
                   t.setValueAt("Biscuits and gravy", 0, 1);
                  
               }
               else if(breakfast.bur.isEnabled()){
                   t.setValueAt("Breakfast burrito", 0, 1);
                  
               }
               else if(breakfast.fren.isEnabled()){
                   t.setValueAt("French toast casserole", 0, 1);
                  
               }else{
                   break;
               }
           
              // t.fireTableCellUpdated(0,1);
          }
           case "Monday" -> {
              
                if(breakfast.pan.isEnabled()){
                   t.setValueAt("Pancakes", 1, 1);  
                 // t.fireTableCellUpdated(0,1);
               }else if(breakfast.chkn.isEnabled()){
                   t.setValueAt("Chicken waffles", 1, 1);
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.av.isEnabled()){
                   t.setValueAt("Avocado toast", 1, 1);
                 // t.fireTableCellUpdated(1,1);
               }
               else if(breakfast.bisc.isEnabled()){
                   t.setValueAt("Biscuits and gravy", 1, 1);
                  
               }
               else if(breakfast.bur.isEnabled()){
                   t.setValueAt("Breakfast burrito", 1, 1);
                  
               }
               else if(breakfast.fren.isEnabled()){
                   t.setValueAt("French toast casserole", 1, 1);
                  
               }else{
                   break;
               }
           
              // t.fireTableCellUpdated(1,1);
           }
          // }
           case "Tuesday" -> {
               if(breakfast.pan.isEnabled()){
                   t.setValueAt("Pancakes", 2, 1);  
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.chkn.isEnabled()){
                   t.setValueAt("Chicken waffles", 2, 1);
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.av.isEnabled()){
                   t.setValueAt("Avocado toast", 2, 1);
                  //t.fireTableCellUpdated(0,1);
               }
               else if(breakfast.bisc.isEnabled()){
                   t.setValueAt("Biscuits and gravy", 2, 1);
                  
               }
               else if(breakfast.bur.isEnabled()){
                   t.setValueAt("Breakfast burrito", 2, 1);
                  
               }
               else if(breakfast.fren.isEnabled()){
                   t.setValueAt("French toast casserole", 2, 1);
                  
               }else{
                   break;
               }
           
               t.fireTableCellUpdated(2,1);
           }
           case "Wednesday" -> {
                if(breakfast.pan.isEnabled()){
                   t.setValueAt("Pancakes", 3, 1);  
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.chkn.isEnabled()){
                   t.setValueAt("Chicken waffles", 3, 1);
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.av.isEnabled()){
                   t.setValueAt("Avocado toast", 3, 1);
                  //t.fireTableCellUpdated(0,1);
               }
               else if(breakfast.bisc.isEnabled()){
                   t.setValueAt("Biscuits and gravy", 3, 1);
                  
               }
               else if(breakfast.bur.isEnabled()){
                   t.setValueAt("Breakfast burrito", 3, 1);
                  
               }
               else if(breakfast.fren.isEnabled()){
                   t.setValueAt("French toast casserole", 3, 1);
                  
               }else{
                   break;
               }
           
               t.fireTableCellUpdated(3,1);

           }
           case "Thursday" -> {
                if(breakfast.pan.isEnabled()){
                   t.setValueAt("Pancakes", 4, 1);  
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.chkn.isEnabled()){
                   t.setValueAt("Chicken waffles", 4, 1);
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.av.isEnabled()){
                   t.setValueAt("Avocado toast", 4, 1);
                  //t.fireTableCellUpdated(0,1);
               }
               else if(breakfast.bisc.isEnabled()){
                   t.setValueAt("Biscuits and gravy", 4, 1);
                  
               }
               else if(breakfast.bur.isEnabled()){
                   t.setValueAt("Breakfast burrito", 4, 1);
                  
               }
               else if(breakfast.fren.isEnabled()){
                   t.setValueAt("French toast casserole", 4, 1);
                  
               }else{
                   break;
               }
           
               t.fireTableCellUpdated(4,1);
           }
           case "Friday" -> {
               if(breakfast.pan.isEnabled()){
                   t.setValueAt("Pancakes", 5, 1);  
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.chkn.isEnabled()){
                   t.setValueAt("Chicken waffles", 5, 1);
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.av.isEnabled()){
                   t.setValueAt("Avocado toast", 5, 1);
                  //t.fireTableCellUpdated(0,1);
               }
               else if(breakfast.bisc.isEnabled()){
                   t.setValueAt("Biscuits and gravy", 5, 1);
                  
               }
               else if(breakfast.bur.isEnabled()){
                   t.setValueAt("Breakfast burrito", 5, 1);
                  
               }
               else if(breakfast.fren.isEnabled()){
                   t.setValueAt("French toast casserole", 5, 1);
                  
               }else{
                   break;
               }
           
               t.fireTableCellUpdated(5,1);

           }
           case "Saturday" -> {
               if(breakfast.pan.isEnabled()){
                   t.setValueAt("Pancakes", 6, 1);  
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.chkn.isEnabled()){
                   t.setValueAt("Chicken waffles", 6, 1);
                  //t.fireTableCellUpdated(0,1);
               }else if(breakfast.av.isEnabled()){
                   t.setValueAt("Avocado toast", 6, 1);
                  //t.fireTableCellUpdated(0,1);
               }
               else if(breakfast.bisc.isEnabled()){
                   t.setValueAt("Biscuits and gravy", 6, 1);
                  
               }
               else if(breakfast.bur.isEnabled()){
                   t.setValueAt("Breakfast burrito", 6, 1);
                  
               }
               else if(breakfast.fren.isEnabled()){
                   t.setValueAt("French toast casserole", 6, 1);
                  
               }else{
                   break;
               }
           
               t.fireTableCellUpdated(6,1);

        }
           
    }
       t.fireTableRowsUpdated(0, 6);

   }
}

      // t.setVisible(true);
       
    

