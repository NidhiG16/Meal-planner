/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lunch;

/**
 *
 * @author user
 */
import java.io.*;
import java.util.*;
import javax.swing.*;
public class Calories {
    public static String line;
    public static ArrayList ing_b,ing;
    public static String[] ib,burg;
    public static int calo_b;
    public static BufferedReader bb;
    public static File rb;
    public static JTextArea ta_b,ta_cal_b;
    public Calories() throws IOException{   
        ArrayList<String> ing_b = new ArrayList<String>();
        ArrayList<String> ing = new ArrayList<String>();
        ta_b = new JTextArea();
        ta_cal_b = new JTextArea();
        try{
            rb = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\ing\\Burger.txt");
            bb = new BufferedReader(new FileReader(rb));  
            while ((line=bb.readLine())!=null) {
                    ib = line.split("-");
                    Collections.addAll(ing, ib[1]);
                    Collections.addAll(ing_b, ib[0]);
             }
            calo_b=0;
            for (String C: ing) {
                    calo_b += Integer.parseInt(C);
                    ta_cal_b.append("\n"+C);
                }            
            for(String I:ing_b){
                    ta_b.append("\n"+I);
                   
                    
                }
            
            ta_b.setEditable(false);
            bb.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
class Fried{
             public static String fry,fs;
             public static ArrayList ing_fr,ing;
             public static String[] i_fr;
             public static int calo_fr;
             public static BufferedReader b_fr;
             public static File r_fr;
             public static JTextArea ta_fr,ta_cal_fr;
             public Fried()throws IOException{
                ArrayList<String> ing_fr = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_fr = new JTextArea();
                ta_cal_fr = new JTextArea();
                try{
                    r_fr = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\ing\\Fried_steak.txt");
                    b_fr = new BufferedReader(new FileReader(r_fr));  
                    while ((fry=b_fr.readLine())!=null) {
                        i_fr = fry.split("-");
                       Collections.addAll(ing, i_fr[1]);
                        Collections.addAll(ing_fr, i_fr[0]);
                }
                calo_fr=0;
                for (String C: ing) {
                        calo_fr += Integer.parseInt(C);
                        ta_cal_fr.append("\n"+C);
                }            
                for(String I:ing_fr){
                    ta_fr.append("\n"+I);
                }
            
                ta_fr.setEditable(false);
                b_fr.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Spag{
             public static String spag,sp;
             public static ArrayList ing_s,ing;
             public static String[] i;
             public static int calo_s;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_s,ta_cal_s;
             public Spag()throws IOException{
                ArrayList<String> ing_s = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_s = new JTextArea();
                ta_cal_s = new JTextArea();
                try{
                    r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\ing\\Spaghetti_pie_casserole.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((spag=b.readLine())!=null) {
                        i = spag.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_s, i[0]);
                }
                calo_s=0;
                for (String C: ing) {
                        calo_s += Integer.parseInt(C);
                        ta_cal_s.append("\n"+C);
                }            
                for(String I:ing_s){
                    ta_s.append("\n"+I);
                }
            
                ta_s.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Meatloaf{
             public static String meat,m;
             public static ArrayList ing_m,ing;
             public static String[] i;
             public static int calo_m;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_m,ta_cal_m;
             public Meatloaf()throws IOException{
                ArrayList<String> ing_m = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_m = new JTextArea();
                ta_cal_m = new JTextArea();
                try{
                    r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\ing\\Meatloaf.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((meat=b.readLine())!=null) {
                        i = meat.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_m, i[0]);
                }
                calo_m=0;
                for (String C: ing) {
                        calo_m += Integer.parseInt(C);
                        ta_cal_m.append("\n"+C);
                }            
                for(String I:ing_m){
                    ta_m.append("\n"+I);
                }
            
                ta_m.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Chick{
             public static String chi,ch;
             public static ArrayList ing_c,ing;
             public static String[] i;
             public static int calo_c;
             public static BufferedReader b;
             public static File r;
             public static JTextArea ta_c,ta_cal_c;
             public Chick()throws IOException{
                ArrayList<String> ing_c = new ArrayList<String>();
                ArrayList<String> ing = new ArrayList<String>();
                ta_c = new JTextArea();
                ta_cal_c = new JTextArea();
                try{
                    r = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\ing\\Chicken_pot_pie.txt");
                    b = new BufferedReader(new FileReader(r));  
                    while ((chi=b.readLine())!=null) {
                        i = chi.split("-");
                       Collections.addAll(ing, i[1]);
                        Collections.addAll(ing_c, i[0]);
                }
                calo_c=0;
                for (String C: ing) {
                        calo_c += Integer.parseInt(C);
                        ta_cal_c.append("\n"+C);
                }            
                for(String I:ing_c){
                    ta_c.append("\n"+I);
                }
            
                ta_c.setEditable(false);
                b.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
       
}
class Cobb{
     public static String line,cs,I;
    public static ArrayList ing_c,ing;
    public static String[] i_c;
    public static int calo_c;
    public static BufferedReader b_c;
    public static File r_c;
    public static JTextArea ta_c,ta_cal_c;
    public Cobb() throws IOException{
            ArrayList<String> ing_c = new ArrayList<String>();
            ArrayList<String> ing = new ArrayList<String>();
            ta_c = new JTextArea();
            ta_cal_c = new JTextArea();
            try{
                r_c = new File("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\ing\\Cobb_salad.txt");
                b_c = new BufferedReader(new FileReader(r_c));  
                while ((line=b_c.readLine())!=null) {
                        i_c = line.split("-");
                        Collections.addAll(ing, i_c[1]);
                        Collections.addAll(ing_c, i_c[0]);
                }
                calo_c=0;
                for (String C: ing) {
                        calo_c += Integer.parseInt(C);
                        ta_cal_c.append("\n"+C);
                }            
                for(String I:ing_c){
                    ta_c.append("\n"+I);
                }
            
                ta_c.setEditable(false);
                b_c.close();
            }catch(IOException e){
                e.printStackTrace();
            }
    }
           
   
}
     



