/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lunch;

/**
 *
 * @author user
 */
import java.io.IOException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import sem3project.*;

/**
 *
 * @author user
 */
public class Plann extends JComboBox {
     public DefaultTableModel t;
   public Plann(String d) throws IOException{
       t = table.dt;
       
       switch (d) {
           case "Sunday" -> {
               if(lunch.burg.isEnabled()){
                   t.setValueAt("Burger", 0, 2);  
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.fs.isEnabled()){
                   t.setValueAt("Fried Steak", 0, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.meat.isEnabled()){
                   t.setValueAt("Meatloaf", 0, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.spag.isEnabled()){
                   t.setValueAt("Spaghetti pir casserole", 0, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.chick.isEnabled()){
                   t.setValueAt("Chicken pot pie", 0, 2);
                   //t.fireTableCellUpdated(0,2);
               }else{
                  break;
               }
              // t.fireTableCellUpdated(0, 2);
           }
           case "Monday" -> {
                if(lunch.burg.isEnabled()){
                   t.setValueAt("Burger", 1, 2);  
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.fs.isEnabled()){
                   t.setValueAt("Fried Steak", 1, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.meat.isEnabled()){
                   t.setValueAt("Meatloaf", 1, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.spag.isEnabled()){
                   t.setValueAt("Spaghetti pir casserole", 1, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.chick.isEnabled()){
                   t.setValueAt("Chicken pot pie", 1, 2);
                   //t.fireTableCellUpdated(0,2);
               }else{
                    break;
                }
              // t.fireTableCellUpdated(1, 2);
           }           
           case "Tuesday" -> {
               if(lunch.burg.isEnabled()){
                   t.setValueAt("Burger", 2, 2);  
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.fs.isEnabled()){
                   t.setValueAt("Fried Steak", 2, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.meat.isEnabled()){
                   t.setValueAt("Meatloaf", 2, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.spag.isEnabled()){
                   t.setValueAt("Spaghetti pir casserole", 2, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.chick.isEnabled()){
                   t.setValueAt("Chicken pot pie", 2, 2);
                   //t.fireTableCellUpdated(0,2);
               }else{
                   break;
               }
               t.fireTableCellUpdated(2, 2);
           }
           
           case "Wednesday" -> {
               if(lunch.burg.isEnabled()){
                   t.setValueAt("Burger", 3, 2);  
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.fs.isEnabled()){
                   t.setValueAt("Fried Steak", 3, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.meat.isEnabled()){
                   t.setValueAt("Meatloaf", 3, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.spag.isEnabled()){
                   t.setValueAt("Spaghetti pir casserole", 3, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.chick.isEnabled()){
                   t.setValueAt("Chicken pot pie", 3, 2);
                   //t.fireTableCellUpdated(0,2);
               }else{
                   break;
               }
               t.fireTableCellUpdated(3, 2);
           
           }
           case "Thursday" -> {
                if(lunch.burg.isEnabled()){
                   t.setValueAt("Burger", 4, 2);  
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.fs.isEnabled()){
                   t.setValueAt("Fried Steak", 4, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.meat.isEnabled()){
                   t.setValueAt("Meatloaf", 4, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.spag.isEnabled()){
                   t.setValueAt("Spaghetti pir casserole", 4, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.chick.isEnabled()){
                   t.setValueAt("Chicken pot pie", 4, 2);
                   //t.fireTableCellUpdated(0,2);
               }else{
                    break;
                }
               t.fireTableCellUpdated(4, 2);
           }               
           case "Friday" -> {
                if(lunch.burg.isEnabled()){
                   t.setValueAt("Burger", 5, 2);  
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.fs.isEnabled()){
                   t.setValueAt("Fried Steak", 5, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.meat.isEnabled()){
                   t.setValueAt("Meatloaf", 5, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.spag.isEnabled()){
                   t.setValueAt("Spaghetti pir casserole", 5, 2);
                   //t.fireTableCellUpdated(0,2);
               }
                else if(lunch.chick.isEnabled()){
                   t.setValueAt("Chicken pot pie", 5, 2);
                   //t.fireTableCellUpdated(0,2);
               }else{
                    break;
                }
               t.fireTableCellUpdated(5, 2);
           
           }
           case "Saturday" -> {
               if(lunch.burg.isEnabled()){
                   t.setValueAt("Burger", 6, 2);  
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.fs.isEnabled()){
                   t.setValueAt("Fried Steak", 6, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.meat.isEnabled()){
                   t.setValueAt("Meatloaf", 6, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.spag.isEnabled()){
                   t.setValueAt("Spaghetti pir casserole", 6, 2);
                   //t.fireTableCellUpdated(0,2);
               }
               else if(lunch.chick.isEnabled()){
                   t.setValueAt("Chicken pot pie", 6, 2);
                   //t.fireTableCellUpdated(0,2);
               }else{
                   break;
               }
               t.fireTableCellUpdated(6, 2);
           
           }
           
       
       }

       t.fireTableRowsUpdated(0, 6);
       
       }
    }


