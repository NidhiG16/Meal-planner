/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lunch;

/**
 *
 * @author user
 */

import breakfast.Planner;
import dinner.Plan_d;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.io.IOException;
import sem3project.*;
import static sem3project.table.dt;
public class lunch extends Frame implements ActionListener{
    public static String l_b,l_f,l_c,l_ch,l_m,l_s; 
    public static int cntr=0;
    public static ButtonGroup bg;
    public static ButtonModel selectedButtonModel;
    public JLabel l3,count,l4,cobb,fried,bur;
    public JList burg_ing,fs_ing,cbs_ing;
    public JPanel ing,ing_d,btn_cal,btn;
    public static JButton burg,fs,cbs,bck,cal_cntr,spag,meat,chick,update;
    public static JFrame f3;
    public Box b,bb;
    public static JScrollPane scroll;
    public static JTextPane ta;
    public lunch() throws IOException
    {
        bg=new ButtonGroup();
        ta=new JTextPane();
        ta.setPreferredSize(new Dimension(400,430));
        ta.setEditable(false);
        scroll=new JScrollPane(ta);
        scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        count = new JLabel();
        btn_cal = new JPanel();
        f3 = new JFrame();
        btn= new JPanel();
        bck = new JButton("BACK");
        cal_cntr = new JButton("Calorie Counter");
        cal_cntr.addActionListener(this);
        bck.addActionListener(this);
        btn_cal.add(count,BorderLayout.PAGE_END);
        btn_cal.add(cal_cntr,BorderLayout.PAGE_END);
        f3.add(btn_cal,BorderLayout.PAGE_END);
        btn.add(bck,BorderLayout.LINE_END);
        f3.add(btn,BorderLayout.LINE_END);
        ing_d = new JPanel();
        update=new JButton("UPDATE");
        new Calories();
        new Fried();
        new Cobb();
        new Chick();
        new Meatloaf();
        new Spag();
        l3=new JLabel();
        l3.setText("Choose your lunch");
        l3.setFont(new Font("Times New Roman",Font.ITALIC|Font.BOLD,20));
        l3.setHorizontalAlignment(JLabel.LEFT);
        ing = new JPanel(new BorderLayout(8,8));
        burg=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\imgs\\burg_icon.jpg")); 
        burg.setText("Burger");
        cbs=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\imgs\\cobb_icon.jpg")); 
        cbs.setText("Cobb Salad");
        fs=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\imgs\\fried_icon.jpg"));
        fs.setText("Fried Steak");
        spag=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\imgs\\spaghetti.jpg")); 
        spag.setText("Spaghetti pie casserole");
        meat=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\imgs\\meat.jpg")); 
        meat.setText("Meatloaf");
        chick=new JButton(new ImageIcon("C:\\Users\\user\\OneDrive\\Documents\\NetBeansProjects\\sem3project\\src\\lunch\\imgs\\chicken-pot-pie.jpg"));
        chick.setText("Chicken pot pie");
        burg.addActionListener(this);
        fs.addActionListener(this);
        cbs.addActionListener(this);
        spag.addActionListener(this);
        chick.addActionListener(this);
        meat.addActionListener(this);
        //ButtonModel = selectedButtonModel;
        b = Box.createVerticalBox();
        bb = Box.createHorizontalBox();
        f3.add(l3,BorderLayout.NORTH);
        b.add(burg);
        b.add(fs);
        b.add(spag);
        b.add(cbs);
        b.add(meat);
        b.add(chick);
        b.setEnabled(false);
        bg.add(burg);
        bg.add(fs);
        bg.add(spag);
        bg.add(cbs);
        bg.add(meat);
        bg.add(chick);
        update.addActionListener(this);
        bb.add(btn);
        bb.add(btn_cal);
        bb.add(update);
        ing.add(b);
        Border btn_border = new EmptyBorder(20,20,20,20);
        ing.setBorder(btn_border);
        ing_d.add(scroll);
        f3.add(ing_d,BorderLayout.WEST);
        f3.add(ing,BorderLayout.WEST);
        f3.add(bb,BorderLayout.SOUTH);
        pack();
        f3.setSize(900, 600);
        f3.setLocationRelativeTo(null);
        f3.setVisible(true);
        
      
    }
    public void actionPerformed(ActionEvent a) {
        l4 = new JLabel("Ingredients",JLabel.CENTER);
        l4.setFont(new Font("Times New Roman",Font.ITALIC|Font.BOLD,20));
        f3.add(l4,BorderLayout.NORTH);
        if(a.getSource()==burg){
            ta.setText("");
            ta.insertComponent(Calories.ta_b);
            cntr+=Calories.calo_b;
            b.setEnabled(false);
            burg.setEnabled(true);
        }
        if(a.getSource()==fs){
            ta.setText("");
            ta.insertComponent(Fried.ta_fr);
            cntr+=Fried.calo_fr;
            b.setEnabled(false);
            fs.setEnabled(true);
        }
        if(a.getSource()==cbs){
            ta.setText("");
            ta.insertComponent(Cobb.ta_c);
            cntr+=Cobb.calo_c;
            b.setEnabled(false);
            cbs.setEnabled(true);
        }
        if(a.getSource()==chick){
            ta.setText("");
            ta.insertComponent(Chick.ta_c);
            cntr+=Chick.calo_c;
            b.setEnabled(false);
            chick.setEnabled(true);
        }
        if(a.getSource()==spag){
            ta.setText("");
            ta.insertComponent(Spag.ta_s);
            cntr+=Spag.calo_s;
            b.setEnabled(false);
            spag.setEnabled(true);
        }
        if(a.getSource()==meat){
            ta.setText("");
            ta.insertComponent(Meatloaf.ta_m);
            cntr+=Meatloaf.calo_m;
            b.setEnabled(false);
            meat.setEnabled(true);
        }
        if(a.getSource()==cal_cntr){
            count.setText("Calorie content: "+cntr+"cal");
            count.setFont(new Font("Times New Roman",Font.BOLD,20));
        }
        if(a.getSource()==update){
            //ButtonModel selectedButtonModel = bg.getSelection();
            dt.fireTableDataChanged();
           
        }
        ing.add(ing_d,BorderLayout.CENTER);
        f3.add(ing,BorderLayout.CENTER);
        f3.setVisible(true);
        if(a.getSource()==bck)
        {
            meal.f1.setVisible(true);
            f3.setVisible(false);
        }
        else{
            f3.setVisible(true);
        
            }
        
     
    }
}
